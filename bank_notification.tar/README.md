# Bank_Notification

銀行維護公告爬取通知

流程配置图：

![image](https://github.com/terry-ian/bank_proclamation/blob/master/images/flowchart.PNG)
